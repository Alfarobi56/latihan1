// Fungsi untuk menambahkan barang ke tabel
function tambahBarang() {
    const namaBarang = document.getElementById('namaBarang').value;
    const jumlah = document.getElementById('jumlah').value;
    const kategori = document.getElementById('kategori').value;

    if (namaBarang && jumlah && kategori) {
        const tabel = document.getElementById('tabelBarang');
        const barisBaru = tabel.insertRow();

        barisBaru.insertCell(0).innerText = namaBarang;
        barisBaru.insertCell(1).innerText = jumlah;
        barisBaru.insertCell(2).innerText = kategori;

        // Reset form
        document.getElementById('barangForm').reset();
    } else {
        alert("Harap isi semua kolom sebelum menambahkan barang!");
    }
}
